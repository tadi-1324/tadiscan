
import 'dart:io';
import 'package:flutter/material.dart';
import 'package:image_picker/image_picker.dart';
import 'package:google_mlkit_text_recognition/google_mlkit_text_recognition.dart';
import 'package:pdf/widgets.dart' as pw;
import 'package:path_provider/path_provider.dart';

void main() {
  runApp(const TadiScanApp());
}

class TadiScanApp extends StatelessWidget {
  const TadiScanApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'TadiScan',
      theme: ThemeData(
        primarySwatch: Colors.indigo,
      ),
      home: const HomePage(),
    );
  }
}

class HomePage extends StatefulWidget {
  const HomePage({super.key});

  @override
  State<HomePage> createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> {
  File? _imageFile;
  String _recognizedText = "";

  Future<void> _pickImage() async {
    final picker = ImagePicker();
    final pickedFile = await picker.pickImage(source: ImageSource.camera);
    if (pickedFile != null) {
      setState(() {
        _imageFile = File(pickedFile.path);
      });
      _performOCR(File(pickedFile.path));
    }
  }

  Future<void> _performOCR(File imageFile) async {
    final inputImage = InputImage.fromFile(imageFile);
    final textRecognizer = TextRecognizer(script: TextRecognitionScript.latin);
    final RecognizedText recognizedText = await textRecognizer.processImage(inputImage);
    setState(() {
      _recognizedText = recognizedText.text;
    });
  }

  Future<void> _exportToPDF() async {
    final pdf = pw.Document();
    if (_imageFile != null) {
      final image = pw.MemoryImage(await _imageFile!.readAsBytes());
      pdf.addPage(pw.Page(build: (pw.Context context) {
        return pw.Center(child: pw.Image(image));
      }));
    }
    final output = await getTemporaryDirectory();
    final file = File("${output.path}/scanned_document.pdf");
    await file.writeAsBytes(await pdf.save());
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(content: Text("PDF saved at ${file.path}")),
    );
  }

  void _magicEraseHandwriting() {
    // TODO: Integrate AI model (e.g., U^2-Net + LaMa inpainting)
    // Steps:
    // 1. Run segmentation on _imageFile to detect handwriting
    // 2. Use inpainting model to erase the handwriting areas
    // 3. Replace _imageFile with new result

    ScaffoldMessenger.of(context).showSnackBar(
      const SnackBar(content: Text("Magic Eraser: AI-based removal is not yet implemented.")),
    );
  }

  void _applyEdgeDetection() {
    // TODO: Integrate edge detection using native OpenCV (via platform channel or plugin)
    // This would allow document boundary detection and auto-cropping
    ScaffoldMessenger.of(context).showSnackBar(
      const SnackBar(content: Text("Edge Detection: OpenCV module not yet integrated.")),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('TadiScan - Smart Scanner')),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          children: [
            if (_imageFile != null)
              Image.file(_imageFile!, height: 300),
            const SizedBox(height: 20),
            ElevatedButton(onPressed: _pickImage, child: const Text("Scan Document")),
            const SizedBox(height: 10),
            ElevatedButton(onPressed: _applyEdgeDetection, child: const Text("Edge Detection")),
            const SizedBox(height: 10),
            ElevatedButton(onPressed: _magicEraseHandwriting, child: const Text("Magic Eraser (AI)")),
            const SizedBox(height: 10),
            ElevatedButton(onPressed: _exportToPDF, child: const Text("Export to PDF")),
            const SizedBox(height: 20),
            Text("OCR Result:", style: Theme.of(context).textTheme.titleLarge),
            Text(_recognizedText),
          ],
        ),
      ),
    );
  }
}
